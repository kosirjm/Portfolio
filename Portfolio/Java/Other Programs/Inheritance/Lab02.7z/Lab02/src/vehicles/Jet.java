package vehicles;

public class Jet extends Aircraft{

	private double FUEL_CAPACITY;
	private double fuel;
	
	/**
	 * @param MAX_PASSANGERS
	 */
	public Jet(int MAX_PASSANGERS, double FUEL_CAPACITY) {
		super(MAX_PASSANGERS);
		this.FUEL_CAPACITY = FUEL_CAPACITY;
	
	}

	public void AddFuel(double amount)
	{
		this.fuel =+ amount;
	}
	
	public double fuelRemaining()
	{
		return fuel;
	}
}
