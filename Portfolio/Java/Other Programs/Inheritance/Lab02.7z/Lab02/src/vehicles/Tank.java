package vehicles;

public class Tank extends GroundVehicle{

	private double FUEL_CAPACITY;
	private double fuel;
	private int MAX_SHELLS;
	private int shells;
	
	/**
	 * @param MAX_PASSANGERS
	 */
	public Tank(int MAX_PASSANGERS, double FUEL_CAPACITY, int MAX_SHELLS) {
		super(MAX_PASSANGERS);
		this.FUEL_CAPACITY = FUEL_CAPACITY;
	
	}

	public void AddFuel(double amount)
	{
		this.fuel =+ amount;
	}
	
	public double fuelRemaining()
	{
		return fuel;
	}
	
	public void fireGun()
	{
		shells =- 1;
	}
	
	public void reload()
	{
		this.shells = MAX_SHELLS;
	}
	
	public int shellsRemaining()
	{
		return this.shells;
	}
}
