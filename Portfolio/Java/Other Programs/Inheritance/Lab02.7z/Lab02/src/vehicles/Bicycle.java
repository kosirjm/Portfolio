package vehicles;

public class Bicycle extends GroundVehicle
{

	public Bicycle(int MAX_PASSENGERS) {
		super(MAX_PASSENGERS);
	}

}
