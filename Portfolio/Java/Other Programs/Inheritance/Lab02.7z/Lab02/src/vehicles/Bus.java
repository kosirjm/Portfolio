package vehicles;

public class Bus extends GroundVehicle{

	private double FUEL_CAPACITY;
	private double fuel;
	/**
	 * @param MAX_PASSENGERS
	 */
	public Bus(int MAX_PASSENGERS, double FUEL_CAPACITY) {
		super(MAX_PASSENGERS);
		this.FUEL_CAPACITY = FUEL_CAPACITY;
	}
	
	public void AddFuel(double amount)
	{
		this.fuel =+ amount;
	}
	
	public double fuelRemaining()
	{
		return fuel;
	}

}
