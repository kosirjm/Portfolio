package vehicles;

public class Vehicle 
{
private int MAX_PASSANGERS;
private int passangers;
private double velocity;


	public Vehicle(int MAX_PASSANGERS)
	{
		this.MAX_PASSANGERS = MAX_PASSANGERS;
	}
	
	public void addPassengers(int newPassangers)
	{
		this.passangers =+ newPassangers;
	}
	
	public int getPassangers()
	{
		return passangers;
	}
	
	public double getVelocity()
	{
		return velocity;
	}
	
	public void removePassangers(int removedPassangers)
	{
		 this.passangers =- removedPassangers;
	}
	
	public void setVelocity(double velocity)
	{
		this.velocity = velocity;
	}
	
}
