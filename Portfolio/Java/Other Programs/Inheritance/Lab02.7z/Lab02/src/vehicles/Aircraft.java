package vehicles;

public class Aircraft extends Vehicle
{
private double altitude;
	
public Aircraft(int MAX_PASSANGERS)
	{
		super(MAX_PASSANGERS);
	}

/**
 * @return the altitude
 */
public double getAltitude() {
	return altitude;
}

/**
 * @param altitude the altitude to set
 */
public void setAltitude(double altitude) {
	this.altitude = altitude;
}
	
}
