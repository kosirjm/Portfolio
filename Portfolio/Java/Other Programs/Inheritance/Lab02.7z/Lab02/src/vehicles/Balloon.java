package vehicles;

public class Balloon extends Aircraft{

	/**
	 * @param MAX_PASSANGERS
	 */
	public Balloon(int MAX_PASSANGERS) {
		super(MAX_PASSANGERS);
	}

}
