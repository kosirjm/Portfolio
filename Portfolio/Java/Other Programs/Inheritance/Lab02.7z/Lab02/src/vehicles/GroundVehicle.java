package vehicles;

public class GroundVehicle extends Vehicle{

	/**
	 * @param MAX_PASSENGERS
	 */
	public GroundVehicle(int MAX_PASSENGERS) {
		super(MAX_PASSENGERS);
	
	}

}
