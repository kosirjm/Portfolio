package Test;
import vehicles.*;

public class Tester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// 1. Create a Balloon capable of carrying 3 passengers.
		Balloon newBalloon = new Balloon(3);
		// 2. Print the number of people currently on the balloon
		System.out.printf("The Balloon Currently holds %d people\n", newBalloon.getPassangers());
		// to the console using printf
		
		// 3. Add 2 passengers to the balloon
			newBalloon.addPassengers(2);	
		// 4. Print the number of people currently on the balloon 
		// to the console using printf
			System.out.printf("The Balloon Currently holds %d people\n", newBalloon.getPassangers());
		// 5. Set the balloon's altitude to 296.4 meters.
		newBalloon.setAltitude(296.4);
		// 6. Print the balloon's altitude to the console to two decimal places using printf
		System.out.printf("The Balloons altitude is %d meters \n", newBalloon.getAltitude());
		// 7. Create a Helicopter capable of carrying two passengers an 2000 pounds of fuel.
		Helicopter newHelicopter = new Helicopter(3,2000);
		// 9. Add one passenger to the helicopter.
		newHelicopter.addPassengers(1);
		
		// 10. Print the number of people currently in the helicopter to the console using
		// a printf statement.
		System.out.printf("There are %i passangers in the helicopter \n", newHelicopter.getPassangers());
		
		// 11. Set the altitude of the helicopter to 600 meters
		newHelicopter.setAltitude(600);
		// 12. Print the helicopter's altitude to the console to two decimal places using printf
		System.out.printf("The helicopters altitude is %d meters \n", newHelicopter.getAltitude());
		// 13. Create a Jet capable of carrying 300 passengers with stall speed of 135 knots and maximum 
		// fuel capacity of 20,000 pounds. Then add 265 passengers to the jet.
		Jet jet = new Jet(300,20000);
		jet.addPassengers(265);
		// 14. Set the Jet's altitude to 9500 meters and its velocity to 402.5 knots.
		jet.setAltitude(9500);
		jet.setVelocity(402.5);
		// 15. Print the jet's altitude and velocity to the console (both values to two decimal places)
		// using a single printf statement. Then print the number of passengers on the jet
		System.out.printf("The jet's altitude is %d meters and its velocity is %d knots \n", jet.getAltitude(), jet.getVelocity());
		System.out.printf("There are %i passengers on the jet", jet.getPassangers());
		// 16. Create a Bus object. The Bus object should have 45 passengers capacity and a 120 gallon fuel tank.
		Bus bus = new Bus(45, 120);
		// 17. Print the number of people and the amount of fuel currently in the bus to the console using printf.
		System.out.printf("There are currently %i people on the bus The bus has %d galloons of fuel", bus.getPassangers(), bus.fuelRemaining());
		// 18. Add 70.45 gallons of fuel and 15 passengers to the bus.
		bus.AddFuel(70.45);
		bus.addPassengers(15);
		// 18. Print the number of people and the amount of fuel currently in the 
		// bus to two decimal places using printf.
		System.out.printf("There are %i people in the bus. The bus has %d gallons of fuel", bus.getPassangers(), bus.fuelRemaining());
		// 19. Create a Bicycle object capable of carrying one passenger.
		Bicycle bicycle = new Bicycle(1);
		// 20. Print the number of people on the bicycle using printf.
		System.out.printf("There are %i people on the bicycle", bicycle.getPassangers());
		// 21. Create a Tank object. Give it the capacity to carry 5 passengers, 
		// 200.7 gallons of fuel and 300 shells.
		Tank tank = new Tank(5, 200.7, 300);
		// 22. Print the number of people in the tank, the amount of fuel carried and the number of 
		// shells on board the tank using a single printf statement.
		System.out.printf("There are %i people in the tank. The tank has %d gallons of fuel and carries %i shells", tank.getPassangers(), tank.fuelRemaining(), tank.shellsRemaining());
		// 23. Add 150 gallons of fuel to the tank, 4 passengers and a full load of shells.
		tank.AddFuel(150);
		tank.addPassengers(4);
		tank.reload();
		// 24. Fire the tank's gun four times.
		tank.fireGun();
		tank.fireGun();
		tank.fireGun();
		tank.fireGun();
		// 25. Print the number of people in the tank, the amount of fuel carried and the number of 
		// shells on board the tank using a single printf statement.
		System.out.printf("There are %i people in the tank. The tank has %d gallons of fuel and carries %i shells", tank.getPassangers(), tank.fuelRemaining(), tank.shellsRemaining());
	}

}
