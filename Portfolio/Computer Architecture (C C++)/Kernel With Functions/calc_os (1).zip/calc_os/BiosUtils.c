#ifndef BIOS_UTILS_C
#define BIOS_UTILS_C

/* The following asm directive informs the assembler to generate */
/* 16-bit code even though gcc spits out 32-bit code.            */
asm(".code16gcc\n");

#include "BiosUtils.h"

void
displayChar(const char text, const byte color) {
    byte data = (byte) text;
    asm("movb $0x00, %%bh\n\t"
        "movw $0x1,  %%cx\n\t"
        "movb %0,    %%al\n\t"
        "movb %1,    %%bl\n"
    : /* No output registers. */
    :"a" (data), "d" (color)
    :"bl", "bh", "cx"
    );
    
    if (data >= 0x20) {
        /* This is a standard character to be displayed. */
        asm("movb $0x9,  %%ah\n\t" /* Display character with color */
            "int  $0x10\n"         /* Display character.           */
        :/* No output registers */
        :/* No inputs expected  */
        :"ah"
        );
    }

    asm("movb $0xe, %%ah\n\t"      /* Display character & interpret */
        "int $0x10\n"              /* special escape codes          */
    :/* No output registers */
    :/* No inputs expected  */
    :"ah"
    );

    if (text == 0xc) {
      // New page
      clearScreen(color);
      moveCursor(0, 0);
    }
}

void
moveCursor(const byte row, const byte column) {
    
    asm("movb %[r], %%dh\n\t"       /* Set the row number in DH    */
        "movb %[c], %%dl\n\t"       /* Set the col number in DL    */
        "movb $0x2, %%ah\n\t"       /* Move cursor function number */
        "movb $0x0, %%bh\n\t"       /* Set page number to 0        */
        "int  $0x10\n"              /* Call int 10h to move cursor */
    : /* No outputs */
    : [r] "a" (row), [c] "b" (column)
    : "dh", "dl"
    );
}

void
getCursor(byte *row, byte *column) {
    byte localRow, localCol;
    asm volatile ("movb $3,   %%ah\n\t"       /* Set function to read cursor */
        "movb $0,   %%bh\n\t"       /* Set video page to 0         */
        "int  $0x10\n\t"            /* Call int 10h to read cursor */
	"movb %%dh, %[row]\n\t"     /* Store row value in variable */
        "movb %%dl, %[col]\n\t"     /* Store col value in variable */
    : [row] "=m" (localRow), [col] "=m" (localCol)
    : 
    : "ax", "bx", "cx", "dx"
    );
    /* Copy values from local variables to parameters */
    *row    = localRow;
    *column = localCol;
}

void
clearScreen(const byte color) {
    /* First move the cursor to top of the screen */
    moveCursor(0, 0);
    
    /* Now write 2000 spaces on the screen thereby clearing it out*/
    asm("movw $0x0920, %%ax\n\t"  /* Select Function 09 and space character */
        "movb $0x0,    %%bh\n\t"  /* Set the page number to 0.              */
        "movw $2000,   %%cx\n\t"  /* Display 2000 spaces in given color.    */
        "int  $0x10\n"            /* Display spaces thereby clear screen!   */
    : /* No outputs */
    : "bl" (color)
    : "ax", "cx"
    );
}

void
displayString(const char *data, const byte color) {
    register short int counter;
    
    for (counter = 0; *(data + counter); counter++) {
        displayChar(*(data + counter), color);
    }
}

void
drawBox(const byte row, const byte column, const int width, const int height,
        const byte color) {
    if ((row > 24) || (column > 79)) {
        /* Invalid starting positions */
        return;
    }
    
    if ((column + width) > 79) {
        /* Cannot draw boxes of this size! */
        return;
    }
    if ((row + height) > 24) {
        /* Cannot draw boxes of this size! */
        return;        
    }
    
    char buffer[80];
    unsigned short int counter;

    /* First display the 2 top and bottom horizontal lines for the box. */
    for(counter = 0; (counter < width); counter++) {
        buffer[counter] = 205; /* See ASCII Table */
    }
    buffer[width] = '\0'; /* Terminate the string properly. */
    
    /* Setup the top-left and top-right corners of the buffer; */
    buffer[0] = 201; /* ASCII for top-left corner */
    buffer[width - 1] = 187; /* ASCII for top-right corner */
    moveCursor(row, column);
    displayString(buffer, color);

    /* Setup the top-left and top-right corners of the buffer; */
    buffer[0] = 200; /* ASCII for top-left corner */
    buffer[width - 1] = 188; /* ASCII for top-right corner */
    moveCursor(row + height, column);
    displayString(buffer, color);
    
    /* Now draw the vertical lines of the box after generating each
       line in the buffer */
    for(counter = 0; (counter < width); counter++) {
        buffer[counter] = ' ';
    }
    buffer[0] = 186;
    buffer[width - 1] = 186;

    for(counter = 1; (counter < height); counter++) {
        moveCursor(row + counter, column);
        displayString(buffer, color);
    }
}

char
haveKeyStroke() {
  unsigned short haveKey = 0;
  asm volatile ("movb $0x1, %%ah\n\t"
		"int $0x16\n\t"
		"jnz haveCode\n\t"
		"xorw %%ax, %%ax\n\t"
		"haveCode: movw %%ax, %[flag]\n\t"
		: [flag] "=g" (haveKey) 
		: /* No input registers. */
		:"ax"
		);
  if (haveKey == 0) {
    return 0;
  }
  return 1;
}

unsigned short
getKeyStroke() {
  unsigned short keyStroke = -1;
  
  asm volatile ("movb $0x0, %%ah\n\t"
		"int $0x16\n\t"
		"movw %%ax, %[key]\n\t"
		: [key] "=m" (keyStroke) 
		: /* No input registers. */
		:"ax"
		);
  return keyStroke;
}

void setIVT(const byte entry, const short isr) {
  unsigned int offset = (entry << 2);
  
  asm volatile ("cli\n\t"
		"pushw %%es\n\t"
		"pushw $0\n\t"
		"popw %%es\n\t"
		"movl %[offset], %%eax\n\t"
		"movw %%cs, %%es:2(%%eax)\n\t"
		"movw %[isr], %%bx\n\t"
		"movw %%bx, %%es:0(%%eax)\n\t"
		"popw %%es\n\t"
		"sti\n\t"
		:  /* No outputs */
		: [isr] "g" (isr), [offset] "g" (offset)
		: "ax", "bx" /* No other clobbered registers */
		);
}

void getIVT(const byte entry, unsigned long *address) {
  unsigned int offset = (entry << 2);
  
  asm volatile ("pushw %%es\n\t"
		"pushw $0\n\t"
		"popw %%es\n\t"
		"movl %[offset], %%eax\n\t"
		"movl %%es:(%%eax), %%ebx\n\t"
		"movl %[addr], %%eax\n\t"
		"movl %%ebx, (%%eax)\n\t"
		"popw %%es\n\t"
		: [addr] "=m" (address)
		: [offset] "g" (offset)
		: "ax", "bx" /* No other clobbered registers */
		);
}

void callISR(const unsigned long address) {
  asm volatile ("pushfw\n\t"
		"lcallw *%[addr]\n\t"
		:
		: [addr] "m" (address)
		: "memory"
		);
}

void getTime(byte* hours, byte* minutes, byte* seconds) {
    /* Use assembly code to invoke interrupt 0x1a to obtain current time
       from the system's Real Time Clock (RTC) */
    asm volatile("movb $2, %%ah\n\t"
		 "int $0x1a\n\t"
		 "movb %%ch, %[hr]\n\t"
		 "movb %%cl, %[min]\n\t"
		 "movb %%dh, %[sec]\n\t"
		 : [hr] "=m" (*hours), [min] "=m" (*minutes), [sec] "=m" (*seconds)
		 : /* No inputs */
		 : "ax", "cx", "dx", "flags" /* Clobbered registers */
		 );
}

#endif
