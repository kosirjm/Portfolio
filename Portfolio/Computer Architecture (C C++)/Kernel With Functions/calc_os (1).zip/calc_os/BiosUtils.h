#ifndef BIOS_UTILS_H
#define BIOS_UTILS_H

#include "Color.h"
#include "DataTypes.h"

/**
   \brief Display a single charachter with a given color.

   This function calls BIOS interrupt 0x10 to display the character
   passed in with the given color.

   \param[in] data The character to be displayed on screen.  Npte that
   the value is internally converted to unsigned byte.  Consequently
   passing in negative values results in changing the value to greater
   than 128 and displays special characters.

   \param[in] The color in which the character is to be displayed.
   Use the \c MAKE_COLOR() macro to define a color consisting of a
   foreground and background color.

   \see MAKE_COLOR
*/
void displayChar(const char data, const byte color);

/**

   This function is a convenience function that displays a string by
   calling \c displayChar on each character.

   \param[in] data The string to be displayed (must be terminted by
   '\0').

   \param[in] color The color in which the character is to be
   displayed.  Use the \c MAKE_COLOR() macro to define a color
   consisting of a foreground and background color.

   \see MAKE_COLOR
*/
void displayString(const char *data, const byte color);

/**
    This function can be used to to move the cursor to a given row and
    column on the screen.  This function uses int 0x10 for achieving
    this functionality.

    \param[in] row The row to which the cursor should be moved.  This
    value must be in the range 0 to 24.

    \param[in] col The column on the screen where the cursor should be
    moved.  This value must be in the range 0 to 79.
*/
void moveCursor(const byte row, const byte column);

/**
    This function can be used to determine the current location of the
    cursor on the screen.  It uses BIOS interrupt 0x10 to determine
    the location of the cursor and then copies the value into the
    parameters specified.

    \param[out] row The row where the cursor is currently located.
    This value is in the range 0 to 24 (inclusive).

    \param[out] column The column where the cursor is currently
    located.  This value is in the range 0 to 79 (inclusive).
*/
void getCursor(byte *row, byte *column);

/**
    This function can be used to clear the contents of the screen by
    filling in blank spaces with the given color.  This can be used to
    change the background of the screen as well.

   \param[in] color The color in which the character is to be
   displayed.  Use the \c MAKE_COLOR() macro to define a color
   consisting of a foreground and background color.

   \see MAKE_COLOR   
*/
void clearScreen(const byte color);

/**
   This function uses the displayString() function to display a series
   of special characters on the screen giving the impression of
   drawing a box.  The characters are printed such that the top-left
   corner of the box is at row and column and its size is width x
   height.

   \param[in] row The row corresponding to the the top-left corner of
   the box.

   \param[in] column The column corresponding to the top-left corner
   of the box.

   \param[in] width The widht of the box to be drawn on screen.

   \param[in] height The height of the box to be drawn on screen.

   \param[in] color The color in which the character is to be
   displayed.  Use the \c MAKE_COLOR() macro to define a color
   consisting of a foreground and background color.

   \see MAKE_COLOR
*/
void
drawBox(const byte row, const byte column, const int width, const int height,
	const byte color);

/**
    This function returns a 1 or 0 value to indicate if a key stroke
    is available or not.  This method uses the BIOS 0x16 function to
    achieve this functionality.

    \return This method returns 0 if no key stroke is pending or
    readily available in the internal buffer.  If a keystroke is
    available then it returns 1.
*/
char haveKeyStroke();

/**
    This function returns a keystroke typed on the keyboard back to
    the caller.  If a keystroke is not readily available, then this
    function blocks until a keystroke is available.  So be careful
    when calling this method if you want to ensure non-blocking
    operations.

    \return This function returns the ASCII code (in least significant
    byte) and scan code for the key pressed (in the most significant
    byte).
*/
unsigned short getKeyStroke();

/**
   Function set a given IVT entry to point to a given interrupt
   service routine.  This method changes the IVT entry corresponding
   to the given interruptNumber to point to cs:isrAddress.

   \param[in] interruptNumber The interrupt number whose IVT entry
   must be modified.

   \param[in] isrAddress The address (offset only, the code segement
   is auotmatically used) where the ISR for the given interrupt is
   located.
 */
void setIVT(const byte interruptNumber, const short isrAddress);

/**
   Function to obtain the IVT entry corresponding to a given interrupt
   number.  This function does <b>not</b> modify the IVT entry.

   \param[in] interruptNumber The interrupt number whose IVT entry
   is to be read and stored in address.

   \param[out] address Pointer to a long where the cs:offset
   associated with the ISR for the given interruptNumber is to be
   copied.  
 */
void getIVT(const byte interruptNumber, unsigned long *address);

/**
   This is a convenience function to invoke an ISR given the full
   address (cs:ip) of the ISR in memory.

   \param[in] addrss The address where the ISR is stored.  This value
   is typically obtained via a call to getIVT() function.

   \note This function does not save any registers.
*/
void callISR(const unsigned long address);

/** \def ISR_CALLER_PROLOGUE

    The following #define macro provides a standard set of assembly
    instructions that serve as a default entry prologue to an ISR.
    The instructions perform the following tasks:

    <OL>

    <LI> First all the general purpose registers are saved (using
    \c pusha instruction)</LI>

    <LI> It pushes \c ds and \c es registers on to the stack </LI>

    <LI> Sets \c ds and \c es to 0 setting it to kernel space. </LI>

    </OL>

    A typical usage of this macro is shown below:

    \code
      void keyboardISRCaller() {
	ISR_CALLER_PROLOGUE();
	// Call the actual ISR.
	keyboardISR();
	ISR_CALLER_EPILOGUE();
      }
    \endcode
*/
#define ISR_CALLER_PROLOGUE() asm volatile ("pushaw\n\t"		\
					    "pushw %ds\n\t"		\
					    "pushw %es\n\t"		\
                                            "xorw %ax, %ax\n\t"		\
                                            "movw %ax, %ds\n\t"		\
                                            "movw %ax, %es\n\t")

/** \def ISR_CALLER_EPILOGUE

     The following #define macro provides a standard set of assembly
     instructions that undo the operations of the ISR_CALLER_PROLOGUE.
     This macro performs the following tasks:

     <OL>

     <LI> Pops \c es and \ds registers off the stack </LI>

     <LI> Pops all general purpose registers off the stack (using \c
     popa instruction)</LI>

     <LI> Resets stack pointer and uses \c iret to exit the ISR</LI>

     </OL>

    A typical usage of this macro is shown below:

    \code
      void keyboardISRCaller() {
	ISR_CALLER_PROLOGUE();
	// Call the actual ISR.
	keyboardISR();
	ISR_CALLER_EPILOGUE();
      }
    \endcode     
*/
#define ISR_CALLER_EPILOGUE() asm volatile("popw %es\n\t"	\
                                           "popw %ds\n\t"	\
                                           "popaw\n\t"		\
	                                   "leave\n\t"		\
	                                   "iretw\n\t")

/** Convenience method to get current time from the BIOS.

    This is a convenience method that can get the current wall-clock
    time via BIOS call.

    \param[out] hours The current hour (time) value.

    \param[out] minutes The current minute (time) value.

    \param[out] seconds The current seconds (time) value.
    
    This method can be used in the following manner:

    \code
    
    byte hour, min, sec;
    getTime(&hour, &min, &sec);
    
    \endcode

 */
void getTime(byte* hours, byte* minutes, byte* seconds);

#endif
