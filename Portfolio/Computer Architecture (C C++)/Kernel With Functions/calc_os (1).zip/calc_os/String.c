#ifndef STRING_C
#define STRING_C

asm(".code16gcc\n");

#include "String.h"


unsigned int strlen(const char *str) {
  int length;
  if (str == NULL) {
    return 0;
  }
  for(length = 0; str[length]; length++);
  return length;
}

char* strcpy(char *dest, const char* src) {
  if ((dest == NULL) || (src == NULL)) {
    return dest;
  }
  int i = 0;
  do {
    dest[i] = src[i];
    i++;
  } while (src[i]);

  return dest;
}


void reverseString(char *str) {
  int i = 0, j = strlen(str) - 1;
  while (i < j) {
    // swap str[i] and str[j]
    char temp = str[i];
    str[i]    = str[j];
    str[j]    = temp;
    i++;
    j--;
  }
}


#endif
