#ifndef STRING_H
#define STRING_H

#include "DataTypes.h"

/** \file String.h

    This file provides alternative implementation for commonly used
    string functions.  These functions replace the standard functions
    supported by glibc.  Note that when developing a custom operating
    system, we cannot rely on libraries from other operating systems.
    Consequently, we have to reimplement core functionality.
*/

/**
   Copy a given number of bytes from src to dest.  This function
   provides implementation for the standard memcpy function.

   \param[out] dest The destination address where the data is to be
   copied.

   \param[in] src The source address from where the data is to be
   copied.

   \param[in] numBytes The number of bytes to be copied from dest to
   src.  If this value is <= 0 then no bytes are copied.
*/
void* memcpy(void *dest, const void* src, const unsigned int numBytes);

/**
   This function replaces the standard string length function.  This
   function counts the number of charachters in \c str (until 0).  If
   the parameter is NULL, then this method returns 0.

   \param[in] str The string whose length is to be computed.
*/
unsigned int strlen(const char *str);


/**
    This function reverses the string str.

    \param[inout] str The string to be reversed.
*/
void reverseString(char *str);


#endif
