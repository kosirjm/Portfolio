/* This macro is necessary to inform the assembler to generate 16-bit
   code even though gcc generates 32-bit code.
*/
asm(".code16gcc\n");

#include "BiosUtils.h"
#include "String.h"

// Forward declaration to make compiler happy
void timerISR();
void displayTime();
void showBanner();
void processLine(char line[], byte color);

// ------------------------------------------------------------------//
//            DO NOT IMPLEMENT ANY METHODS BEFORE _start             //
// ------------------------------------------------------------------//
void _start() {
    // Set up background timer-based operations
    setIVT(0x1c, (int) timerISR);

    // Display a simple startup message (this can be made fancy using the
    // drawBox function in BiosUtils.h
    showBanner();

    // The operations of the OS go here. For now, it does nothing
    // other than pretend to process keystrokes.
    char line[81];
    int col = 0, color = 0;
    do {
	// Read and store a keystroke
	byte key = getKeyStroke();
	// Echo it back on screen for user to see.
	displayChar(key, MAKE_COLOR(WHITE, BLACK));
	// Fake "enter" key moves to next line (via helper function)
	if (key == '\r') {
	    displayChar('\n', MAKE_COLOR(WHITE, BLACK));
            line[col] = '\0';
            processLine(line, 9 + color);
            color = (color + 1) % 6;
            col   = 0;
	} else {
            line[col++] = key;
        }
    } while (true);
}

void showBanner() {
    clearScreen(MAKE_COLOR(WHITE, BLACK));
    const byte color = MAKE_COLOR(WHITE, RED);
    drawBox(2, 10, 60, 7, color);
    moveCursor(4, 28);
    displayString("Custom Operating System", color);
    moveCursor(5, 22);
    displayString("Copyright (C) 2014 raodm@miamiOH.edu", color);
    moveCursor(6, 32);
    displayString("Miami University", color);
    moveCursor(7, 34);
    displayString("Oxford, OHIO", color);
    moveCursor(11, 1);
    displayString("Type lines and press enter", MAKE_COLOR(WHITE, BLACK));
    moveCursor(12, 1);
}

void processLine(char line[], byte color) {
    // Count words in the line.
    int wordCount = 0;
    int currPos   = 0;
    while (line[currPos] != '\0') {
        while ((line[currPos] != '\0') && (line[currPos] == ' ')) {
            currPos++;
        }
        if (line[currPos] != '\0') {
            while ((line[currPos] != '\0') && (line[currPos] != ' ')) {
                currPos++;
            }
            wordCount++;
        }
    }
    // Reverse and print the string
    reverseString(line);
    displayString(line, color);
    // Print the cout of words in hex
    char wordMsg[80] = "\r\nWord count: 0x0\r\n";
    wordMsg[16]      = (wordCount < 10 ? ('0' + wordCount) :
                        ('a' + wordCount - 10));
    displayString(wordMsg, color);
}

/**
   A simple timer Interrupt Service Routine (ISR). This function is
   automatically invoked by the BIOS 19 times a second.  It can be
   used for context switching or performing some short background
   operations.  NOTE: Keep this method fast!
*/
void timerISR() {
    // The following line is crtical & must be the first line in this function
    ISR_CALLER_PROLOGUE();

    // The body of the ISR goes here!
    displayTime();
    
    // The following line is critical & must be the last line in this function
    ISR_CALLER_EPILOGUE();
}

/**
   This function is called via the Timer Interrupt Service Routine
   (ISR) about 19.2 times a second.  This function should display the
   current time at the top-right corner of the screen.
 */
void displayTime() {
}

// End of source code.
