#ifndef DATA_TYPES_H
#define DATA_TYPES_H

#ifndef byte
typedef unsigned char byte;
#endif

#ifndef NULL
#define NULL 0
#endif

#ifndef true
#define true 1
#endif

#ifndef false
#define false 0
#endif

#endif
